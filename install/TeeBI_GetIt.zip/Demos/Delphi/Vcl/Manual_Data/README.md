## Create TDataItem structures by code

![Screenshot](https://raw.githubusercontent.com/Steema/BI/master/docs/img/manual_data/manual_data_example.png)

[Click here for more images](https://github.com/Steema/BI/wiki/Creating-TDataItem-by-code)






