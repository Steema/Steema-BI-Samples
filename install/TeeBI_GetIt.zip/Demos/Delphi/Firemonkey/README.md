### TeeBI demos for Delphi Firemonkey framework

Supported IDEs:  RAD Studio XE5 and up


