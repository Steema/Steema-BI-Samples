TeeBI Speed FMX
================

The example TeeBI_Speed_FMX does a Speed Benchmark Tests.
It uses the BI.Tests.Speed unit which contains several predefined tasks in order to test the speed of some of the TeeBI funcionalities.


![screenshot](https://raw.githubusercontent.com/Steema/BI/master/demos/delphi/firemonkey/Speed/img/TeeBI_SpeedTest.png "TeeBI Speed Test")


