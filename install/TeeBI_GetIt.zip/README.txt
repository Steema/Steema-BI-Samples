Welcome to TeeBI Component Library !
------------------------------------

Latest version and more demos:

https://github.com/Steema/TeeBI


Homepage:

https://www.steema.com/product/teebi


---------------

Installation:
=============

Run the TeeBIRecompile.exe tool.

(Administrator privilege required to copy compiled packages)

See the INSTALL.txt file for details about recompilation and installation.


Documentation:

--------------
https://github.com/Steema/TeeBI/wiki


Support:
--------

Note this is an opensource project, community auto-managed.

Please use the GitHub homepage Issues page for requests:

https://github.com/Steema/TeeBI/issues


---------------------------------------